<?php
/* =========================================================================
   Group Number: Group 7
   Group Members: S24810493 WONG Lai Man (Max), YULIN LIAO, JIEYI WANG
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Page 7 of 8 - Frequently Asked Questions Page (faq.php) using Bootstrap 5 Accordion
   ========================================================================= */

$pageTitle = "Frequently Asked Questions (FAQ) | Hong Kong Computer Society (HKCS)";
require_once __DIR__ . '/includes/header.php';
?>

<!-- Start of Sub-Page Grey Title Banner: Matches official HKCS light-grey inner page header -->
<section class="py-4" style="background-color: #e2e2e2;">
    <div class="container">
        <h1 class="h3 fw-normal mb-0 text-dark">Frequently Asked Questions (FAQ)</h1>
    </div>
</section>
<!-- End of Sub-Page Grey Title Banner -->

<!-- Start of FAQ Accordion Section: Structured Q&A for Membership, iAM Smart, Events, and Account Support -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="mb-4">
                    <h2 class="h5 fw-bold text-dark mb-2">Membership, Events &amp; Portal Support</h2>
                    <p class="text-secondary small">Find quick answers to common questions regarding HKCS membership grades, student privileges, iAM Smart digital cards, and event registration.</p>
                </div>

                <!-- Official Bootstrap 5 Accordion Component -->
                <div class="accordion" id="hkcsFaqAccordion">
                    <!-- FAQ Item 1 -->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="faqHeadingOne">
                            <button class="accordion-button fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseOne" aria-expanded="true" aria-controls="faqCollapseOne">
                                1. Who is eligible for FREE HKCS Student Membership?
                            </button>
                        </h2>
                        <div id="faqCollapseOne" class="accordion-collapse collapse show" aria-labelledby="faqHeadingOne" data-bs-parent="#hkcsFaqAccordion">
                            <div class="accordion-body small text-secondary" style="line-height: 1.7;">
                                All full-time students enrolled in Higher Diploma, Associate Degree, or Undergraduate programmes in Information Technology, Computer Science, Cybersecurity, or related disciplines at recognized Hong Kong tertiary institutions are eligible for <strong>FREE Student Membership</strong>. You can submit your application directly on our <a href="register.php" class="fw-bold text-decoration-none" style="color: #10069f;">Membership Registration Page</a>.
                            </div>
                        </div>
                    </div>

                    <!-- FAQ Item 2 -->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="faqHeadingTwo">
                            <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseTwo" aria-expanded="false" aria-controls="faqCollapseTwo">
                                2. How do I activate my HKCS Digital Membership Card on iAM Smart?
                            </button>
                        </h2>
                        <div id="faqCollapseTwo" class="accordion-collapse collapse" aria-labelledby="faqHeadingTwo" data-bs-parent="#hkcsFaqAccordion">
                            <div class="accordion-body small text-secondary" style="line-height: 1.7;">
                                Once your membership application is approved, log in to the <a href="login.php" class="fw-bold text-decoration-none" style="color: #10069f;">HKCS Member Portal</a> and navigate to "Digital Membership Card". Follow the on-screen QR authentication prompt to bind your membership credential with your Hong Kong Government <strong>iAM Smart</strong> mobile app.
                            </div>
                        </div>
                    </div>

                    <!-- FAQ Item 3 -->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="faqHeadingThree">
                            <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseThree" aria-expanded="false" aria-controls="faqCollapseThree">
                                3. What is the difference between Associate Member and Full Member?
                            </button>
                        </h2>
                        <div id="faqCollapseThree" class="accordion-collapse collapse" aria-labelledby="faqHeadingThree" data-bs-parent="#hkcsFaqAccordion">
                            <div class="accordion-body small text-secondary" style="line-height: 1.7;">
                                <strong>Associate Membership</strong> is designed for recent ICT graduates and early-career professionals entering the industry. <strong>Full Membership (MHKCS)</strong> is awarded to experienced practitioners holding recognized academic qualifications and relevant professional experience in computing, cybersecurity, or IT management.
                            </div>
                        </div>
                    </div>

                    <!-- FAQ Item 4 -->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="faqHeadingFour">
                            <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseFour" aria-expanded="false" aria-controls="faqCollapseFour">
                                4. How are Continuing Professional Development (CPD) hours recorded?
                            </button>
                        </h2>
                        <div id="faqCollapseFour" class="accordion-collapse collapse" aria-labelledby="faqHeadingFour" data-bs-parent="#hkcsFaqAccordion">
                            <div class="accordion-body small text-secondary" style="line-height: 1.7;">
                                When you register and check in at eligible HKCS seminars, summits, or Specialist Group workshops listed on our <a href="events.php" class="fw-bold text-decoration-none" style="color: #10069f;">Events &amp; Programmes Page</a>, your attendance is automatically logged into your annual CPD transcript.
                            </div>
                        </div>
                    </div>

                    <!-- FAQ Item 5 -->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="faqHeadingFive">
                            <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseFive" aria-expanded="false" aria-controls="faqCollapseFive">
                                5. What should I do if I forget my Member Portal password?
                            </button>
                        </h2>
                        <div id="faqCollapseFive" class="accordion-collapse collapse" aria-labelledby="faqHeadingFive" data-bs-parent="#hkcsFaqAccordion">
                            <div class="accordion-body small text-secondary" style="line-height: 1.7;">
                                Visit our <a href="forget-password.php" class="fw-bold text-decoration-none" style="color: #10069f;">Password Recovery Page</a> and enter your registered email address. A secure password reset link will be sent to your inbox within a few minutes.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Support Callout Box linking to Contact Page -->
                <div class="mt-5 p-4 border bg-light d-flex flex-wrap justify-content-between align-items-center gap-3">
                    <div>
                        <h5 class="h6 fw-bold text-dark mb-1">Still have questions?</h5>
                        <p class="small text-muted mb-0">Our Secretariat team in Tsim Sha Tsui East is happy to assist with your membership or event inquiries.</p>
                    </div>
                    <a href="contact.php" class="btn btn-hkcs-primary rounded-0 px-4">Contact Secretariat</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of FAQ Accordion Section -->

<?php
require_once __DIR__ . '/includes/footer.php';
?>