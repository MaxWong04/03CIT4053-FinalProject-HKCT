<?php
// =========================================================================
// Step 1: Load Composer's autoloader and import PHPMailer namespaces
// 第一步：載入 Composer 自動載入器並匯入 PHPMailer 命名空間
// =========================================================================
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php';

$statusMessage = '';
$alertType = '';

// Process form submission when the user clicks "Send Test Email"
// 當使用者點擊「發送測試電郵」時處理表單提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recipientEmail = trim($_POST['recipient_email'] ?? '');
    $subject        = trim($_POST['subject'] ?? '');
    $messageBody    = trim($_POST['message'] ?? '');

    // Create a new PHPMailer instance (passing `true` enables exceptions)
    // 建立 PHPMailer 實例（傳入 true 啟用例外錯誤處理）
    $mail = new PHPMailer(true);

    try {
        // =================================================================
        // Step 2: Configure Gmail SMTP Server Settings
        // 第二步：設定 Gmail SMTP 伺服器參數
        // =================================================================
        // Set to SMTP::DEBUG_SERVER (2) if you need detailed connection logs
        // 若需查看詳細連線除錯訊息，可將下方改為 SMTP::DEBUG_SERVER
        $mail->SMTPDebug = SMTP::DEBUG_OFF;

        $mail->isSMTP();                                            // Send using SMTP / 使用 SMTP 協定發信
        $mail->Host       = 'smtp.gmail.com';                       // Gmail SMTP server / Gmail SMTP 主機位址
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication / 啟用 SMTP 身份驗證

        // =================================================================
        // Step 3: Enter Your Gmail Address & 16-Digit Google App Password
        // 第三步：填入你的 Gmail 帳號與 16 位數 Google 應用程式密碼
        // =================================================================
        $mail->Username   = 'immaxwong@gmail.com';                  // Your Gmail address / 你的 Gmail 信箱
        $mail->Password   = 'vraz zsmo sune tsoy';                  // Your 16-digit App Password / 你的 16 位數應用程式密碼

        // Encryption & Port Settings: STARTTLS on Port 587 (Recommended)
        // 加密與埠號設定：使用 Port 587 搭配 STARTTLS 加密（官方建議）
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Character encoding to prevent garbled Chinese characters
        // 設定 UTF-8 編碼，防止繁體中文標題或內文出現亂碼
        $mail->CharSet    = 'UTF-8';

        // Sender and Recipient configuration (matches authenticated Username)
        // 寄件人與收件人設定（與上方驗證信箱保持一致）
        $mail->setFrom($mail->Username, 'HKCS System Notification');
        $mail->addAddress($recipientEmail);

        // Email Content / 郵件內容設定
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = nl2br(htmlspecialchars($messageBody, ENT_QUOTES, 'UTF-8'));
        $mail->AltBody = $messageBody;

        $mail->send();
        $alertType = 'success';
        $statusMessage = 'Success! Test email has been sent to ' . htmlspecialchars($recipientEmail, ENT_QUOTES, 'UTF-8') . '.<br>成功！測試郵件已發送至上述信箱。';
    } catch (Exception $e) {
        $alertType = 'danger';
        $statusMessage = 'Mailer Error / 發信失敗: ' . htmlspecialchars($mail->ErrorInfo, ENT_QUOTES, 'UTF-8');
    }
}
?>
<!DOCTYPE html>
<html lang="zh-HK">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHPMailer Gmail SMTP Test | 寄信功能測試</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light py-5">
    <div class="container" style="max-width: 620px;">
        <div class="card shadow-sm border-0">
            <div class="card-header text-white fw-bold py-3" style="background-color: #10069f;">
                PHPMailer + Gmail SMTP Test (Lab Demo) | 郵件發送測試
            </div>
            <div class="card-body p-4">
                <?php if (!empty($statusMessage)): ?>
                    <div class="alert alert-<?php echo $alertType; ?>" role="alert">
                        <?php echo $statusMessage; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="recipient_email" class="form-label fw-bold">Recipient Email | 收件人電郵</label>
                        <input type="email" class="form-control" id="recipient_email" name="recipient_email" placeholder="example@gmail.com" required>
                    </div>
                    <div class="mb-3">
                        <label for="subject" class="form-label fw-bold">Subject | 郵件主旨</label>
                        <input type="text" class="form-control" id="subject" name="subject" value="HKCS Password Reset / 密碼重設驗證測試" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label fw-bold">Message Body | 郵件內容</label>
                        <textarea class="form-control" id="message" name="message" rows="4" required>Hello Max, this is a test email sent via PHPMailer v7.2.0 and Gmail SMTP.</textarea>
                    </div>
                    <button type="submit" class="btn text-white fw-bold w-100" style="background-color: #10069f;">
                        Send Test Email | 立即發送測試郵件
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>