<?php
/* =========================================================================
   Group Number: [Group 7]
   Group Members: S24810493 WONG Lai Man (Max), [YULIN LIAO], [JIEYI WANG]
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Global PHP data configuration storing navigation items, events, and local image paths
   ========================================================================= */

if (!defined('HKCS_DATA_LOADED')) {
    define('HKCS_DATA_LOADED', true);

    // HKCS Secretariat contact details
    $contactInfo = [
        'address' => 'Room 1003, 10/F, Harbour Crystal Centre, 100 Granville Road, Tsim Sha Tsui East, Kowloon, Hong Kong',
        'email'   => 'hkcs@hkcs.org.hk',
        'phone'   => '(852) 2834-2228'
    ];

    // Primary navigation items connecting core PHP pages
    $navItems = [
        ['text' => 'HOME',                'url' => 'index.php'],
        ['text' => 'EVENTS & PROGRAMMES', 'url' => 'events.php'],
        ['text' => 'FEATURED SUMMIT',     'url' => 'event-detail.php'],
        ['text' => 'FAQ',                 'url' => 'faq.php'],
        ['text' => 'CONTACT US',          'url' => 'contact.php'],
        ['text' => 'MEMBER LOGIN',        'url' => 'login.php'],
        ['text' => 'REGISTER',            'url' => 'register.php']
    ];

    // Hero carousel banners using strictly local relative paths inside assets/img/
    $carouselBanners = [
        ['image' => 'assets/img/banner-ebook-2025.jpg',   'alt' => 'HKCS Collection of Articles 2025'],
        ['image' => 'assets/img/banner-iam-smart.jpg',    'alt' => 'HKCS Digital Membership Card on iAM Smart'],
        ['image' => 'assets/img/banner-corp-member.jpg',  'alt' => 'HKCS New Corporate Membership Packages'],
        ['image' => 'assets/img/banner-ciso-board.jpg',   'alt' => 'HKCS CISO Board and 55th Anniversary'],
        ['image' => 'assets/img/banner-student-promo.jpg','alt' => 'Join HKCS Student Membership for FREE']
    ];

    // Upcoming events and professional programmes list for index.php and events.php
    $upcomingEvents = [
        [
            'id'       => 1,
            'badge'    => 'Award',
            'category' => 'award',
            'title'    => 'HKICTA 2026: Smart Business Award',
            'date'     => '2026-12-10 | 14:00 - 17:30',
            'venue'    => 'Hong Kong Convention and Exhibition Centre (HKCEC)',
            'cpd'      => '3.0 CPD Hours',
            'fee'      => 'Free for HKCS Members',
            'image'    => 'assets/img/banner-corp-member.jpg',
            'desc'     => 'We welcome entries from Financial Services, Logistics, Retail, and Smart Trade business areas across Hong Kong.'
        ],
        [
            'id'       => 2,
            'badge'    => 'Cybersecurity',
            'category' => 'cybersecurity',
            'title'    => 'HKCS Cybersecurity & AI Summit 2026',
            'date'     => '2026-12-18 | 09:30 - 17:00',
            'venue'    => 'Cyberport Conference & Exhibition Centre, Pok Fu Lam',
            'cpd'      => '6.0 CPD Hours',
            'fee'      => 'HK$200 (Free for Student Members)',
            'image'    => 'assets/img/banner-ciso-board.jpg',
            'desc'     => 'Bringing together Chief Information Security Officers (CISOs) and AI experts to discuss zero-trust architecture and threat intelligence.'
        ],
        [
            'id'       => 3,
            'badge'    => 'Digital Identity',
            'category' => 'conference',
            'title'    => 'iAM Smart Digital Membership Onboarding Workshop',
            'date'     => '2027-01-08 | 15:00 - 17:00',
            'venue'    => 'HKCS Secretariat Training Room, TST East',
            'cpd'      => '2.0 CPD Hours',
            'fee'      => 'Free for All Members',
            'image'    => 'assets/img/banner-iam-smart.jpg',
            'desc'     => 'Learn how to activate your HKCS Digital Membership Card via iAM Smart for seamless event check-in and CPD tracking.'
        ],
        [
            'id'       => 4,
            'badge'    => 'Publication',
            'category' => 'conference',
            'title'    => 'HKCS Annual Thought Leadership Symposium',
            'date'     => '2027-01-22 | 14:00 - 18:00',
            'venue'    => 'Hong Kong Science Park (HKSTP), Sha Tin',
            'cpd'      => '3.5 CPD Hours',
            'fee'      => 'HK$150 (Free for Student Members)',
            'image'    => 'assets/img/banner-ebook-2025.jpg',
            'desc'     => 'Authors of the HKCS Collection of Articles share insights on FinTech, Smart City infrastructure, and Cloud governance.'
        ],
        [
            'id'       => 5,
            'badge'    => 'Student Career',
            'category' => 'student',
            'title'    => 'ICT Young Talent & Cybersecurity Career Fair',
            'date'     => '2027-02-05 | 10:00 - 17:00',
            'venue'    => 'Kowloonbay International Trade & Exhibition Centre',
            'cpd'      => '4.0 CPD Hours',
            'fee'      => 'Free Admission for Full-Time Students',
            'image'    => 'assets/img/banner-student-promo.jpg',
            'desc'     => 'Connect directly with top Hong Kong ICT employers, explore internship opportunities, and join mock technical interviews.'
        ],
        [
            'id'       => 6,
            'badge'    => 'Governance',
            'category' => 'cybersecurity',
            'title'    => 'CISO Board Briefing: Compliance & Data Privacy',
            'date'     => '2027-02-19 | 16:00 - 18:30',
            'venue'    => 'Harbour Crystal Centre, Tsim Sha Tsui East',
            'cpd'      => '2.5 CPD Hours',
            'fee'      => 'HK$100 (Free for CISO Board & Student Members)',
            'image'    => 'assets/img/banner-ciso-board.jpg',
            'desc'     => 'Executive briefing on cross-border data compliance, PDPO guidelines, and critical infrastructure protection.'
        ]
    ];

    // Functional Units data for index.php
    $functionalUnits = [
        [
            'title' => 'CIO Board',
            'desc'  => 'The CIO Board is a group of CIOs and Heads of IT from prominent organizations in Hong Kong providing a strategic platform for knowledge sharing.',
            'link'  => 'events.php'
        ],
        [
            'title' => 'CISO Board',
            'desc'  => 'The CISO Board brings together Chief Information Security Officers to share threat intelligence and elevate cybersecurity standards.',
            'link'  => 'event-detail.php?id=2'
        ],
        [
            'title' => 'Specialist Groups',
            'desc'  => 'HKCS Specialist Groups (SG) form the cornerstone of technical excellence in Artificial Intelligence, Cyber Security, FinTech, and Robotics.',
            'link'  => 'events.php'
        ],
        [
            'title' => 'Industry Groups',
            'desc'  => 'Serving as a bridge between IT professionals and sector leaders across Construction, Health Tech, Retail Tech, and Startups.',
            'link'  => 'contact.php'
        ],
        [
            'title' => 'iLEAP',
            'desc'  => 'IT Leadership Accelerator Platform (iLEAP) empowers mid-to-senior IT managers with executive leadership capabilities.',
            'link'  => 'register.php'
        ],
        [
            'title' => 'FACE Club',
            'desc'  => 'The first ICT women club in Hong Kong dedicated to attracting, connecting, and engaging female IT talent.',
            'link'  => 'faq.php'
        ]
    ];
}