<?php
/* =========================================================================
   Group Number: Group 7
   Group Members: S24810493 WONG Lai Man (Max), YULIN LIAO, JIEYI WANG
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Shared PHP Footer reproducing the exact HKCS light off-white footer layout
   ========================================================================= */
?>
    </main>
    <!-- End of Main Content Wrapper -->

    <!-- Start of Official HKCS Light Footer: Reproduces exact social icons, white logo box, copyright & links -->
    <footer class="pt-4 pb-4" style="background-color: #f7f7f7;">
        <div class="container">
            <!-- Top Subtle Horizontal Divider Line matching official screenshot -->
            <hr class="mt-0 mb-4" style="border-top: 1px solid #d5d5d5; opacity: 1;">

            <!-- Upper Footer Row: Left Social Icons & Right White-Boxed HKCS Logo -->
            <div class="row align-items-center justify-content-between g-3 mb-4">
                <!-- Upper Left: 4 Small Grey Social Media Icons (Pure Inline SVGs) -->
                <div class="col-md-6 d-flex align-items-center gap-3">
                    <a href="contact.php" class="text-secondary text-decoration-none" title="Facebook" aria-label="Facebook">
                        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                        </svg>
                    </a>
                    <a href="contact.php" class="text-secondary text-decoration-none" title="LinkedIn" aria-label="LinkedIn">
                        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z"/>
                        </svg>
                    </a>
                    <a href="contact.php" class="text-secondary text-decoration-none" title="Twitter" aria-label="Twitter">
                        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
                        </svg>
                    </a>
                    <a href="contact.php" class="text-secondary text-decoration-none" title="YouTube" aria-label="YouTube">
                        <svg width="15" height="15" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z"/>
                        </svg>
                    </a>
                </div>

                <!-- Upper Right: HKCS Vector Logo Inside Crisp White Rectangular Box -->
                <div class="col-md-6 text-md-end">
                    <a href="index.php" class="d-inline-block bg-white px-3 py-2 text-decoration-none" title="Hong Kong Computer Society">
                        <img src="assets/img/hkcs-logo.png" alt="Hong Kong Computer Society Footer Logo" height="46">
                            <g transform="translate(0, 5)">
                                <rect x="0" y="0" width="32" height="100" rx="2" fill="#002b66" />
                                <path d="M 10 0 L 22 0 L 22 40 L 32 40 L 32 60 L 22 60 L 22 100 L 10 100 Z" fill="#ffffff" />
                                <rect x="36" y="0" width="100" height="100" rx="2" fill="#009640" />
                                <path d="M 116 24 C 94 12, 62 24, 62 50 C 62 76, 94 88, 116 76 L 116 60 C 100 68, 80 62, 80 50 C 80 38, 100 32, 116 40 Z" fill="#ffffff" />
                                <path d="M 104 38 C 94 34, 88 42, 94 48 C 100 54, 108 52, 108 60 C 108 68, 90 68, 86 62 L 93 54 C 97 58, 102 58, 102 54 C 102 50, 94 51, 94 43 C 94 35, 108 33, 110 42 Z" fill="#009640" />
                            </g>
                            <g fill="#002b66">
                                <text x="155" y="32" font-family="'Segoe UI', Arial, Helvetica, sans-serif" font-weight="900" font-size="27" letter-spacing="1">HONG KONG</text>
                                <text x="155" y="62" font-family="'Segoe UI', Arial, Helvetica, sans-serif" font-weight="900" font-size="27" letter-spacing="0.5">COMPUTER SOCIETY</text>
                                <text x="155" y="96" font-family="'Microsoft JhengHei', 'PingFang TC', sans-serif" font-weight="900" font-size="30" letter-spacing="3.5">香港電腦學會</text>
                            </g>
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Lower Footer Row: Left Copyright Notice & Right Official Blue Links -->
            <div class="row align-items-center justify-content-between g-2 pt-2" style="font-size: 0.78rem;">
                <!-- Lower Left: Copyright Notice -->
                <div class="col-lg-5 text-secondary">
                    Copyright (c) <?php echo date('Y'); ?> Hong Kong Computer Society. All Rights Reserved.
                </div>

                <!-- Lower Right: 5 Official Blue Footer Links mapped to working project PHP pages -->
                <div class="col-lg-7 text-lg-end">
                    <div class="d-flex flex-wrap justify-content-lg-end gap-3">
                        <a href="index.php" class="text-decoration-none" style="color: #10069f;">Introduction</a>
                        <a href="login.php" class="text-decoration-none" style="color: #10069f;">Membership Renewal</a>
                        <a href="faq.php" class="text-decoration-none" style="color: #10069f;">Privacy Statement</a>
                        <a href="events.php" class="text-decoration-none" style="color: #10069f;">Web Accessibility Statement</a>
                        <a href="contact.php" class="text-decoration-none" style="color: #10069f;">Contact Us</a>
                    </div>
                </div>
            </div>

            <!-- Subtle All-8-Pages Quick Index ensuring 1-click access across all required project pages -->
            <div class="mt-3 pt-2 border-top text-center text-lg-end" style="font-size: 0.72rem; border-color: #e5e5e5 !important;">
                <span class="text-muted me-2">Site Pages:</span>
                <a href="index.php" class="text-secondary text-decoration-none me-2">Home</a>
                <a href="login.php" class="text-secondary text-decoration-none me-2">Member Login</a>
                <a href="register.php" class="text-secondary text-decoration-none me-2">Join Now</a>
                <a href="forget-password.php" class="text-secondary text-decoration-none me-2">Forget Password</a>
                <a href="events.php" class="text-secondary text-decoration-none me-2">Events</a>
                <a href="event-detail.php" class="text-secondary text-decoration-none me-2">Featured Event</a>
                <a href="faq.php" class="text-secondary text-decoration-none me-2">FAQ</a>
                <a href="contact.php" class="text-secondary text-decoration-none">Contact Us</a>
            </div>
        </div>
    </footer>
    <!-- End of Official HKCS Light Footer -->

    <!-- Official Bootstrap 5.3.3 JS Bundle CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom project JavaScript file -->
    <script src="assets/js/main.js"></script>
</body>
</html>