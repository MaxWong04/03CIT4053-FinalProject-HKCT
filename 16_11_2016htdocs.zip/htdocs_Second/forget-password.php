<?php
/* =========================================================================
   Group Number: Group 7
   Group Members: S24810493 WONG Lai Man (Max), YULIN LIAO, JIEYI WANG
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Page 4 of 8 - Faithful rebuild of HKCS Forgot Your Password Page (forget-password.php)
   ========================================================================= */

$pageTitle = "Forgot your password? | Hong Kong Computer Society (HKCS)";
$resetMessage = "";
$resetStatus = "";

// Handle PHP POST password reset request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['reset_email'] ?? '');

    if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $safeEmail = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
        $resetStatus = "success";
        $resetMessage = "Password reset instructions have been sent to <strong>{$safeEmail}</strong>. Please check your inbox and spam folder.";
    } else {
        $resetStatus = "danger";
        $resetMessage = "Please enter a valid registered email address.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Responsive viewport meta tag for desktop, tablet (768px), and mobile (576px) -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?></title>

    <!-- Official Bootstrap 5.3.3 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom global stylesheet using relative path -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Page-specific styles reproducing the exact HKCS Password Recovery Portal layout -->
    <style>
        /* Top Portal Header */
        .portal-header {
            background-color: #ffffff;
            border-bottom: 1px solid #e5e7eb;
        }
        .portal-nav-link {
            color: #6c757d;
            font-size: 0.85rem;
            text-decoration: none;
            padding: 1.25rem 0.5rem;
            display: inline-block;
        }
        .portal-nav-link:hover {
            color: #24b4a5;
        }

        /* Clean White Main Form Section */
        .recovery-white-section {
            background-color: #ffffff;
        }

        /* Wide Light-Grey Email Input Box matching official screenshot */
        .recovery-input {
            background-color: #e6e8ec !important;
            border: 1px solid #c8ccd4 !important;
            border-radius: 2px !important;
            height: 34px;
            font-size: 0.88rem;
            padding: 4px 10px;
            width: 100%;
            max-width: 720px;
        }
        .recovery-input:focus {
            background-color: #ffffff !important;
            border-color: #24b4a5 !important;
            box-shadow: 0 0 0 0.15rem rgba(36, 180, 165, 0.2) !important;
        }

        /* Teal Send Button */
        .btn-portal-teal {
            background-color: #24b4a5;
            border-color: #24b4a5;
            color: #ffffff;
            font-size: 0.82rem;
            padding: 5px 16px;
            border-radius: 3px;
        }
        .btn-portal-teal:hover {
            background-color: #1d9689;
            border-color: #1d9689;
            color: #ffffff;
        }

        /* Supporting Partner Organizations Strip */
        .portal-partners {
            background-color: #ffffff;
            font-size: 0.72rem;
            color: #6c757d;
        }

        /* Dark Charcoal Portal Footer */
        .portal-footer {
            background-color: #333333;
            color: #cccccc;
            font-size: 0.75rem;
        }
        .portal-footer a {
            color: #cccccc;
            text-decoration: none;
        }
        .portal-footer a:hover {
            color: #ffffff;
            text-decoration: underline;
        }

        /* Subtle Lavender-Blue Geometric Tech Backdrop below footer (Pure CSS + Inline SVG Data URI) */
        .portal-bottom-backdrop {
            background-color: #eef0f8;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Cg fill='none' stroke='%23d4d9ec' stroke-width='1.2'%3E%3Cpolygon points='50,30 180,90 120,210'/%3E%3Cpolygon points='180,90 340,40 290,190'/%3E%3Cpolygon points='340,40 520,110 430,240'/%3E%3Cpolygon points='120,210 290,190 220,340'/%3E%3Cpolygon points='290,190 430,240 380,370'/%3E%3Ccircle cx='180' cy='90' r='3' fill='%23c5cce6'/%3E%3Ccircle cx='290' cy='190' r='3' fill='%23c5cce6'/%3E%3Ccircle cx='430' cy='240' r='3' fill='%23c5cce6'/%3E%3C/g%3E%3C/svg%3E");
            background-size: cover;
            background-position: center;
            flex-grow: 1;
            min-height: 180px;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Start of Minimalist Portal Header: HKCS Vector SVG Logo + News & Sign in links -->
    <header class="portal-header">
        <div class="container d-flex justify-content-between align-items-center py-2">
            <!-- HKCS Official Vector SVG Logo linking back to Home Page -->
            <a href="index.php" class="d-flex align-items-center text-decoration-none" title="Hong Kong Computer Society">
                <img src="assets/img/hkcs-logo.png" alt="HKCS Logo" height="70">
                    <g transform="translate(0, 5)">
                        <rect x="0" y="0" width="32" height="100" rx="2" fill="#002b66" />
                        <path d="M 10 0 L 22 0 L 22 40 L 32 40 L 32 60 L 22 60 L 22 100 L 10 100 Z" fill="#ffffff" />
                        <rect x="36" y="0" width="100" height="100" rx="2" fill="#009640" />
                        <path d="M 116 24 C 94 12, 62 24, 62 50 C 62 76, 94 88, 116 76 L 116 60 C 100 68, 80 62, 80 50 C 80 38, 100 32, 116 40 Z" fill="#ffffff" />
                        <path d="M 104 38 C 94 34, 88 42, 94 48 C 100 54, 108 52, 108 60 C 108 68, 90 68, 86 62 L 93 54 C 97 58, 102 58, 102 54 C 102 50, 94 51, 94 43 C 94 35, 108 33, 110 42 Z" fill="#009640" />
                    </g>
                    <g fill="#002b66">
                        <text x="155" y="32" font-family="'Segoe UI', Arial, sans-serif" font-weight="900" font-size="27" letter-spacing="1">HONG KONG</text>
                        <text x="155" y="62" font-family="'Segoe UI', Arial, sans-serif" font-weight="900" font-size="27" letter-spacing="0.5">COMPUTER SOCIETY</text>
                        <text x="155" y="96" font-family="'Microsoft JhengHei', sans-serif" font-weight="900" font-size="30" letter-spacing="3.5">香港電腦學會</text>
                    </g>
                </svg>
            </a>

            <!-- Right Portal Navigation Links (News & Sign in) -->
            <nav class="d-flex align-items-center gap-3">
                <a href="events.php" class="portal-nav-link">News</a>
                <a href="login.php" class="portal-nav-link">Sign in</a>
            </nav>
        </div>
    </header>
    <!-- End of Minimalist Portal Header -->

    <!-- Start of Main Forgot Password Form Section: Reproduces exact official layout -->
    <main class="recovery-white-section pt-5 pb-4">
        <div class="container" style="max-width: 860px;">
            <!-- Section Heading with Bottom Horizontal Divider -->
            <div class="border-bottom pb-2 mb-4">
                <h1 class="h5 fw-normal text-dark mb-0" style="font-size: 1.25rem;">Forgot your password?</h1>
            </div>

            <!-- Server-Side PHP POST Feedback Message -->
            <?php if (!empty($resetMessage)): ?>
                <div class="alert alert-<?php echo $resetStatus; ?> py-2 px-3 small mb-4" style="max-width: 720px;" role="alert">
                    <?php echo $resetMessage; ?>
                </div>
            <?php endif; ?>

            <!-- Password Reset Request Form -->
            <form method="POST" action="forget-password.php" class="pb-4">
                <!-- Email Input with Red Asterisk -->
                <div class="mb-2">
                    <label for="resetEmail" class="form-label mb-1" style="font-size: 0.78rem; color: #555555;">
                        <span class="text-danger fw-bold">*</span> Email
                    </label>
                    <input type="email" class="form-control recovery-input" id="resetEmail" name="reset_email" required>
                </div>

                <!-- Instruction Helper Text matching screenshot -->
                <p class="mb-3" style="font-size: 0.78rem; color: #333333;">
                    Enter your email address to request a password reset.
                </p>

                <!-- Teal Send Action Button & Return to Sign in Link -->
                <div class="d-flex align-items-center gap-3">
                    <button type="submit" class="btn btn-portal-teal">Send</button>
                    <a href="login.php" style="font-size: 0.78rem; color: #2b7bb9; text-decoration: none;">
                        &larr; Back to Sign in
                    </a>
                </div>
            </form>
        </div>
    </main>
    <!-- End of Main Forgot Password Form Section -->

    <!-- Supporting Government & Industry Organizations Strip -->
    <div class="portal-partners py-2 text-center">
        <div class="container">
            <span>Innovation, Technology and Industry Bureau</span>
            <span class="mx-2">|</span>
            <span>Digital Policy Office</span>
            <span class="mx-2">|</span>
            <span>Innovation and Technology Commission</span>
            <span class="mx-2">|</span>
            <span>Hong Kong Productivity Council</span>
            <span class="mx-2">|</span>
            <span>APICTA</span>
        </div>
    </div>

    <!-- Start of Dark Charcoal Portal Footer: Matches official footer + ensures all 8 pages are reachable -->
    <footer class="portal-footer py-3">
        <div class="container">
            <div class="row align-items-center g-2">
                <!-- Left Spacer on Desktop -->
                <div class="col-md-3 d-none d-md-block"></div>

                <!-- Center Social Icons & Copyright Statement -->
                <div class="col-md-6 text-center">
                    <!-- Inline SVG Social Icons (Facebook, Twitter, YouTube) -->
                    <div class="d-flex justify-content-center gap-3 mb-2">
                        <a href="contact.php" title="Facebook" aria-label="Facebook">
                            <svg width="13" height="13" viewBox="0 0 16 16" fill="currentColor"><path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/></svg>
                        </a>
                        <a href="contact.php" title="Twitter" aria-label="Twitter">
                            <svg width="13" height="13" viewBox="0 0 16 16" fill="currentColor"><path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/></svg>
                        </a>
                        <a href="contact.php" title="YouTube" aria-label="YouTube">
                            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z"/></svg>
                        </a>
                    </div>

                    <div class="mb-2">
                        <span>Copyright (c) <?php echo date('Y'); ?> Hong Kong Computer Society. All Rights Reserved.</span>
                        <span class="ms-3">Powered by APJ</span>
                    </div>

                    <!-- Direct Navigation Strip ensuring all 8 required pages are reachable from forget-password.php -->
                    <div class="pt-1 border-top border-secondary border-opacity-50" style="font-size: 0.7rem;">
                        <a href="index.php">Home</a> &middot;
                        <a href="login.php">Login</a> &middot;
                        <a href="register.php">Register</a> &middot;
                        <a href="forget-password.php">Forget Password</a> &middot;
                        <a href="events.php">Events</a> &middot;
                        <a href="event-detail.php">Event Detail</a> &middot;
                        <a href="faq.php">FAQ</a> &middot;
                        <a href="contact.php">Contact</a>
                    </div>
                </div>

                <!-- Right Security Seal Badge (Pure Inline SVG - Zero external images) -->
                <div class="col-md-3 text-center text-md-end">
                    <svg width="96" height="32" viewBox="0 0 120 40" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="SSL Secured Badge">
                        <rect x="1" y="1" width="118" height="38" rx="19" fill="#ffffff" stroke="#cccccc" stroke-width="1"/>
                        <path d="M22 18v-3a5 5 0 0 1 10 0v3h1a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H21a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1zm3 0h4v-3a2 2 0 0 0-4 0v3z" fill="#0066cc"/>
                        <text x="41" y="21" font-family="Arial, sans-serif" font-weight="bold" font-size="12" fill="#003366">digicert</text>
                        <text x="41" y="30" font-family="Arial, sans-serif" font-weight="bold" font-size="6.5" letter-spacing="1" fill="#666666">SECURED</text>
                    </svg>
                </div>
            </div>
        </div>
    </footer>
    <!-- End of Dark Charcoal Portal Footer -->

    <!-- Decorative Geometric Lower Backdrop matching official screenshot -->
    <div class="portal-bottom-backdrop" aria-hidden="true"></div>

    <!-- Official Bootstrap 5.3.3 JS Bundle CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>