<?php
/* =========================================================================
   Group Number: Group 7
   Group Members: S24810493 WONG Lai Man (Max), YULIN LIAO, JIEYI WANG
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Page 5 of 8 - Item Listing Page (events.php) displaying all HKCS events and programmes
   ========================================================================= */

$pageTitle = "Events & Programmes | Hong Kong Computer Society (HKCS)";
require_once __DIR__ . '/includes/header.php';
?>

<!-- Start of Sub-Page Grey Title Banner: Matches official HKCS light-grey inner page header -->
<section class="py-4" style="background-color: #e2e2e2;">
    <div class="container">
        <h1 class="h3 fw-normal mb-0 text-dark">Events &amp; Professional Programmes</h1>
    </div>
</section>
<!-- End of Sub-Page Grey Title Banner -->

<!-- Start of Events Listing Section: Filterable grid showcasing all HKCS events and courses -->
<section class="py-5 bg-white">
    <div class="container">
        <!-- Section Intro & Category Filter Bar -->
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4 pb-3 border-bottom">
            <div>
                <h2 class="h5 fw-bold text-dark mb-1">Upcoming Conferences, Awards &amp; CPD Seminars</h2>
                <p class="text-muted small mb-0">Explore industry events and earn Continuing Professional Development (CPD) hours</p>
            </div>

            <!-- Interactive Category Filter Buttons (Pure Bootstrap + Vanilla JS) -->
            <div class="btn-group flex-wrap" role="group" aria-label="Event category filter">
                <button type="button" class="btn btn-sm btn-hkcs-primary event-filter-btn active" data-filter="all">All Events</button>
                <button type="button" class="btn btn-sm btn-hkcs-outline event-filter-btn" data-filter="cybersecurity">Cybersecurity</button>
                <button type="button" class="btn btn-sm btn-hkcs-outline event-filter-btn" data-filter="award">Awards</button>
                <button type="button" class="btn btn-sm btn-hkcs-outline event-filter-btn" data-filter="conference">Conferences</button>
                <button type="button" class="btn btn-sm btn-hkcs-outline event-filter-btn" data-filter="student">Student &amp; Career</button>
            </div>
        </div>

        <!-- Responsive Event Cards Grid (3 columns on desktop, 2 on tablet, 1 on mobile) -->
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4" id="eventsListGrid">
            <?php if (!empty($upcomingEvents)): ?>
                <?php foreach ($upcomingEvents as $event): ?>
                    <div class="col event-grid-item" data-category="<?php echo htmlspecialchars($event['category'], ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="card h-100 hkcs-card overflow-hidden">
                            <!-- Local Event Banner Thumbnail -->
                            <img src="<?php echo htmlspecialchars($event['image'], ENT_QUOTES, 'UTF-8'); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo htmlspecialchars($event['title'], ENT_QUOTES, 'UTF-8'); ?>"
                                 style="height: 170px; object-fit: cover;">

                            <div class="card-body d-flex flex-column p-4">
                                <!-- Category Badge & CPD Hours -->
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="badge text-white" style="background-color: var(--hkcs-accent);">
                                        <?php echo htmlspecialchars($event['badge'], ENT_QUOTES, 'UTF-8'); ?>
                                    </span>
                                    <span class="badge bg-light text-dark border">
                                        <?php echo htmlspecialchars($event['cpd'], ENT_QUOTES, 'UTF-8'); ?>
                                    </span>
                                </div>

                                <!-- Event Title -->
                                <h5 class="card-title fw-bold mb-2" style="color: var(--hkcs-primary); font-size: 1.05rem;">
                                    <?php echo htmlspecialchars($event['title'], ENT_QUOTES, 'UTF-8'); ?>
                                </h5>

                                <!-- Date & Venue Metadata -->
                                <p class="small text-dark fw-semibold mb-1">
                                    Date: <?php echo htmlspecialchars($event['date'], ENT_QUOTES, 'UTF-8'); ?>
                                </p>
                                <p class="small text-muted mb-3">
                                    Venue: <?php echo htmlspecialchars($event['venue'], ENT_QUOTES, 'UTF-8'); ?>
                                </p>

                                <!-- Event Short Description -->
                                <p class="card-text small text-secondary flex-grow-1">
                                    <?php echo htmlspecialchars($event['desc'], ENT_QUOTES, 'UTF-8'); ?>
                                </p>

                                <!-- Action Link to Item Detail Page -->
                                <div class="pt-3 border-top mt-2 d-flex justify-content-between align-items-center">
                                    <span class="small fw-bold text-muted"><?php echo htmlspecialchars($event['fee'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    <a href="event-detail.php?id=<?php echo (int)$event['id']; ?>" class="btn btn-sm btn-hkcs-primary rounded-0 px-3">
                                        View Details
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End of Events Listing Section -->

<!-- Client-side category filter script for Events Listing Page -->
<script>
document.addEventListener("DOMContentLoaded", function () {
    const filterButtons = document.querySelectorAll(".event-filter-btn");
    const eventItems = document.querySelectorAll(".event-grid-item");

    filterButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            // Update active button styling
            filterButtons.forEach(function (btn) {
                btn.classList.remove("btn-hkcs-primary", "active");
                btn.classList.add("btn-hkcs-outline");
            });
            this.classList.remove("btn-hkcs-outline");
            this.classList.add("btn-hkcs-primary", "active");

            const selectedCategory = this.getAttribute("data-filter");

            // Show or hide cards matching the chosen category
            eventItems.forEach(function (item) {
                const itemCategory = item.getAttribute("data-category");
                if (selectedCategory === "all" || itemCategory === selectedCategory) {
                    item.classList.remove("d-none");
                } else {
                    item.classList.add("d-none");
                }
            });
        });
    });
});
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>