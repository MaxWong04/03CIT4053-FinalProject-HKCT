<?php
/* =========================================================================
   Group Number: Group 7
   Group Members: S24810493 WONG Lai Man (Max), YULIN LIAO, JIEYI WANG
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Page 8 of 8 - Contact Us Page (contact.php) with Secretariat info and PHP POST inquiry form
   ========================================================================= */

$pageTitle = "Contact Us | Hong Kong Computer Society (HKCS)";
$contactFeedback = "";

// Handle PHP POST inquiry form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senderName    = trim($_POST['sender_name'] ?? '');
    $senderEmail   = trim($_POST['sender_email'] ?? '');
    $inquiryTopic  = trim($_POST['inquiry_topic'] ?? '');
    $messageText   = trim($_POST['message_text'] ?? '');

    if (!empty($senderName) && !empty($senderEmail) && !empty($messageText)) {
        $safeName  = htmlspecialchars($senderName, ENT_QUOTES, 'UTF-8');
        $safeTopic = htmlspecialchars($inquiryTopic, ENT_QUOTES, 'UTF-8');
        $contactFeedback = "Thank you, <strong>{$safeName}</strong>! Your inquiry regarding <strong>{$safeTopic}</strong> has been received by the HKCS Secretariat. We will respond within 2 working days.";
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Start of Sub-Page Grey Title Banner: Matches official HKCS light-grey inner page header -->
<section class="py-4" style="background-color: #e2e2e2;">
    <div class="container">
        <h1 class="h3 fw-normal mb-0 text-dark">Contact Us</h1>
    </div>
</section>
<!-- End of Sub-Page Grey Title Banner -->

<!-- Start of Contact Information & Inquiry Form Section: Two-column responsive layout -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="row g-5">
            <!-- Left Column (5 cols): HKCS Secretariat Address, Phone, Email, and Office Hours -->
            <div class="col-lg-5">
                <h2 class="h5 fw-bold text-dark mb-3">HKCS Secretariat Office</h2>
                <p class="small text-secondary mb-4" style="line-height: 1.7;">
                    For membership applications, event sponsorships, Specialist Group participation, or general inquiries, please reach out to our Secretariat using the details below.
                </p>

                <div class="p-4 border bg-light mb-4" style="border-top: 4px solid #10069f !important;">
                    <div class="mb-3 pb-3 border-bottom">
                        <h6 class="fw-bold small text-uppercase mb-1" style="color: #10069f;">Office Address</h6>
                        <p class="small text-dark mb-0">
                            Room 1003, 10/F, Harbour Crystal Centre,<br>
                            100 Granville Road, Tsim Sha Tsui East,<br>
                            Kowloon, Hong Kong
                        </p>
                    </div>

                    <div class="mb-3 pb-3 border-bottom">
                        <h6 class="fw-bold small text-uppercase mb-1" style="color: #10069f;">Telephone &amp; Fax</h6>
                        <p class="small text-dark mb-0">
                            Tel: (852) 2834-2228<br>
                            Fax: (852) 2834-3003
                        </p>
                    </div>

                    <div class="mb-3 pb-3 border-bottom">
                        <h6 class="fw-bold small text-uppercase mb-1" style="color: #10069f;">General Email</h6>
                        <p class="small mb-0">
                            <a href="mailto:hkcs@hkcs.org.hk" class="text-decoration-none fw-bold" style="color: #10069f;">hkcs@hkcs.org.hk</a>
                        </p>
                    </div>

                    <div>
                        <h6 class="fw-bold small text-uppercase mb-1" style="color: #10069f;">Office Hours</h6>
                        <p class="small text-secondary mb-0">
                            Monday – Friday: 09:00 – 18:00<br>
                            Saturday, Sunday &amp; Public Holidays: Closed
                        </p>
                    </div>
                </div>

                <!-- Quick Links to FAQ and Registration -->
                <div class="small text-muted">
                    Looking for quick answers? Check our <a href="faq.php" class="fw-bold text-decoration-none" style="color: #10069f;">Frequently Asked Questions</a> or <a href="register.php" class="fw-bold text-decoration-none" style="color: #10069f;">Online Application Forms</a>.
                </div>
            </div>

            <!-- Right Column (7 cols): Interactive PHP POST Online Inquiry Form -->
            <div class="col-lg-7">
                <div class="p-4 p-md-5 border bg-white shadow-sm">
                    <h2 class="h5 fw-bold mb-2" style="color: #10069f;">Send Us an Online Message</h2>
                    <p class="small text-muted mb-4">Please fill in the form below and our team will get back to you promptly.</p>

                    <?php if (!empty($contactFeedback)): ?>
                        <div class="alert alert-success small" role="alert">
                            <?php echo $contactFeedback; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="contact.php">
                        <div class="row g-3">
                            <!-- Sender Name -->
                            <div class="col-md-6">
                                <label for="senderName" class="form-label fw-bold small">Your Name</label>
                                <input type="text" class="form-control" id="senderName" name="sender_name" placeholder="e.g., WONG Lai Man Max" required>
                            </div>

                            <!-- Sender Email -->
                            <div class="col-md-6">
                                <label for="senderEmail" class="form-label fw-bold small">Email Address</label>
                                <input type="email" class="form-control" id="senderEmail" name="sender_email" placeholder="e.g., max@example.com" required>
                            </div>

                            <!-- Phone Number -->
                            <div class="col-md-6">
                                <label for="senderPhone" class="form-label fw-bold small">Contact Number (Optional)</label>
                                <input type="tel" class="form-control" id="senderPhone" name="sender_phone" placeholder="e.g., 9123 4567">
                            </div>

                            <!-- Inquiry Topic Dropdown -->
                            <div class="col-md-6">
                                <label for="inquiryTopic" class="form-label fw-bold small">Subject / Department</label>
                                <select class="form-select" id="inquiryTopic" name="inquiry_topic" required>
                                    <option value="Membership & Student Application">Membership &amp; Student Application</option>
                                    <option value="Events, Summits & CPD">Events, Summits &amp; CPD</option>
                                    <option value="CISO / CIO Board & Specialist Groups">CISO / CIO Board &amp; Specialist Groups</option>
                                    <option value="Member Portal Technical Support">Member Portal Technical Support</option>
                                    <option value="General Inquiry">General Inquiry</option>
                                </select>
                            </div>

                            <!-- Message Textarea -->
                            <div class="col-12">
                                <label for="messageText" class="form-label fw-bold small">Message Details</label>
                                <textarea class="form-control" id="messageText" name="message_text" rows="5" placeholder="Please type your inquiry or feedback here..." required></textarea>
                            </div>

                            <!-- Submit Inquiry Button -->
                            <div class="col-12 mt-3">
                                <button type="submit" class="btn btn-hkcs-primary rounded-0 px-5 py-2">
                                    SEND MESSAGE
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of Contact Information & Inquiry Form Section -->

<?php
require_once __DIR__ . '/includes/footer.php';
?>