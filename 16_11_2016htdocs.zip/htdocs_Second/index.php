<?php
/* =========================================================================
   Group Number: Group 7
   Group Members: S24810493 WONG Lai Man (Max), YULIN LIAO, JIEYI WANG
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Page 1 of 8 - Home Page (index.php) with Hero Carousel and Responsive Grids
   ========================================================================= */

$pageTitle = "Home | Hong Kong Computer Society (HKCS)";
require_once __DIR__ . '/includes/header.php';
?>

<!-- Start of Hero Carousel Section: Full-width banner showcase with arrows, dots, and thumbnail strip -->
<section class="hero-carousel-fullwidth">
    <div class="carousel-main-container">
        <!-- Loop through $carouselBanners array defined in includes/data.php -->
        <?php if (!empty($carouselBanners)): ?>
            <?php foreach ($carouselBanners as $index => $banner): ?>
                <div class="carousel-slide <?php echo $index === 0 ? 'active' : ''; ?>">
                    <!-- Strictly local image paths, NO external fallback URLs -->
                    <img src="<?php echo htmlspecialchars($banner['image'], ENT_QUOTES, 'UTF-8'); ?>" 
                         alt="<?php echo htmlspecialchars($banner['alt'], ENT_QUOTES, 'UTF-8'); ?>" 
                         class="carousel-image">
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Previous and Next slide arrow buttons -->
        <button class="carousel-arrow prev" aria-label="Previous slide">&lsaquo;</button>
        <button class="carousel-arrow next" aria-label="Next slide">&rsaquo;</button>
    </div>

    <!-- Thumbnail preview navigation strip synchronized with main slides -->
    <div class="carousel-thumbnail-strip pt-3 pb-3" style="background-color: #1a1a1a;">
        <div class="container d-flex justify-content-center flex-wrap gap-2 gap-md-3">
            <?php if (!empty($carouselBanners)): ?>
                <?php foreach ($carouselBanners as $index => $banner): ?>
                    <div class="thumbnail-item <?php echo $index === 0 ? 'active' : ''; ?>" data-slide="<?php echo $index; ?>">
                        <img src="<?php echo htmlspecialchars($banner['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="Thumbnail <?php echo $index + 1; ?>">
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End of Hero Carousel Section -->

<!-- Start of Upcoming Events Section: Highlights flagship awards and conferences -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold" style="color: var(--hkcs-primary);">Upcoming Events</h2>
            <p class="text-muted">Find out more about our upcoming events, awards, and supporting initiatives</p>
        </div>

        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <!-- Event Card 1 -->
            <div class="col">
                <div class="card h-100 hkcs-card p-4">
                    <div class="mb-2">
                        <span class="badge text-white" style="background-color: var(--hkcs-accent);">Award</span>
                    </div>
                    <h5 class="fw-bold" style="color: var(--hkcs-primary);">HKICTA 2026: Smart Business Award</h5>
                    <p class="text-muted small flex-grow-1">We welcome innovative entries from Financial Services, Logistics, Retail, and Smart Trade business areas across Hong Kong.</p>
                    <a href="event-detail.php?id=1" class="fw-bold text-decoration-none small" style="color: var(--hkcs-primary);">Read More &rarr;</a>
                </div>
            </div>

            <!-- Event Card 2 -->
            <div class="col">
                <div class="card h-100 hkcs-card p-4">
                    <div class="mb-2">
                        <span class="badge text-white" style="background-color: var(--hkcs-accent);">Cybersecurity</span>
                    </div>
                    <h5 class="fw-bold" style="color: var(--hkcs-primary);">HKCS Cybersecurity &amp; AI Summit 2026</h5>
                    <p class="text-muted small flex-grow-1">Join CISOs, security researchers, and AI practitioners to explore enterprise defense and zero-trust governance.</p>
                    <a href="event-detail.php?id=2" class="fw-bold text-decoration-none small" style="color: var(--hkcs-primary);">Read More &rarr;</a>
                </div>
            </div>

            <!-- Event Card 3 -->
            <div class="col">
                <div class="card h-100 hkcs-card p-4">
                    <div class="mb-2">
                        <span class="badge text-white" style="background-color: var(--hkcs-accent);">Conference</span>
                    </div>
                    <h5 class="fw-bold" style="color: var(--hkcs-primary);">Hong Kong International Computer Conference</h5>
                    <p class="text-muted small flex-grow-1">Our flagship annual conference bringing together global ICT leaders to shape Hong Kong's digital economy.</p>
                    <a href="events.php" class="fw-bold text-decoration-none small" style="color: var(--hkcs-primary);">View All Events &rarr;</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of Upcoming Events Section -->

<!-- Start of About HKCS Introduction Banner -->
<section class="intro-section py-5 text-center">
    <div class="container py-3">
        <h2 class="fw-bold mb-3">About Hong Kong Computer Society</h2>
        <p class="lead mx-auto mb-3" style="max-width: 820px; font-weight: 300;">Established in 1970, HKCS is the first non-profit professional body devoted to building Hong Kong&rsquo;s ICT industry and advancing professional standards.</p>
        <p class="mb-4 text-white-50">Our members come from a wide range of ICT disciplines across executive, professional, and academic sectors.</p>
        <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="register.php" class="btn btn-light fw-bold px-4" style="color: var(--hkcs-primary);">Become a Member</a>
            <a href="faq.php" class="btn btn-outline-light fw-bold px-4 text-white">Membership FAQ</a>
        </div>
    </div>
</section>
<!-- End of About HKCS Introduction Banner -->

<!-- Start of Functional Units Section -->
<section class="py-5" style="background-color: var(--hkcs-bg-light);">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold" style="color: var(--hkcs-primary);">Functional Units</h2>
            <p class="text-muted">Empowerment through key governance boards and specialist groups</p>
        </div>

        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php if (!empty($functionalUnits)): ?>
                <?php foreach ($functionalUnits as $unit): ?>
                    <div class="col">
                        <div class="card h-100 hkcs-card p-4">
                            <h5 class="fw-bold" style="color: var(--hkcs-primary);">
                                <?php echo htmlspecialchars($unit['title'], ENT_QUOTES, 'UTF-8'); ?>
                            </h5>
                            <p class="text-muted small flex-grow-1">
                                <?php echo htmlspecialchars($unit['desc'], ENT_QUOTES, 'UTF-8'); ?>
                            </p>
                            <a href="<?php echo htmlspecialchars($unit['link'], ENT_QUOTES, 'UTF-8'); ?>" class="fw-bold text-decoration-none small" style="color: var(--hkcs-primary);">
                                Explore Details &rarr;
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End of Functional Units Section -->

<?php
require_once __DIR__ . '/includes/footer.php';
?>