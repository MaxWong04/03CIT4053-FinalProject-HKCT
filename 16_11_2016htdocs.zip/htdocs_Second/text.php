<!doctype html>
<html lang="zh-HK">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hong Kong Computer Society | 香港電腦學會</title>
    
    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        /* 自訂樣式 */
        :root {
            --hkcs-blue: #003366;
            --hkcs-light-blue: #0066cc;
            --hkcs-grey: #f5f5f5;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* 頂部導航 */
        .navbar-brand {
            font-weight: bold;
            color: var(--hkcs-blue) !important;
        }
        
        .nav-link {
            color: #333;
            font-weight: 500;
        }
        
        .nav-link:hover {
            color: var(--hkcs-light-blue);
        }
        
        /* 橫幅區域 */
        .carousel-item img {
            height: 400px;
            object-fit: cover;
        }
        
        /* 簡介區域 */
        .intro-section {
            background: linear-gradient(135deg, var(--hkcs-blue) 0%, var(--hkcs-light-blue) 100%);
            color: white;
            padding: 60px 0;
        }
        
        /* 功能單位卡片 */
        .functional-card {
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            height: 100%;
        }
        
        .functional-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        
        .functional-card .card-icon {
            font-size: 3rem;
            color: var(--hkcs-light-blue);
        }
        
        /* 活動區域 */
        .event-card {
            border-left: 4px solid var(--hkcs-light-blue);
            background: var(--hkcs-grey);
        }
        
        /* CTA 區域 */
        .cta-section {
            background: var(--hkcs-blue);
            color: white;
            padding: 60px 0;
        }
        
        .btn-cta {
            background: white;
            color: var(--hkcs-blue);
            padding: 12px 30px;
            font-weight: bold;
        }
        
        .btn-cta:hover {
            background: var(--hkcs-grey);
        }
        
        /* Footer */
        footer {
            background: #1a1a1a;
            color: white;
            padding: 40px 0 20px;
        }
    </style>
</head>
<body>

    <!-- 頂部導航欄 -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="bi bi-pc-display-horizontal me-2"></i>
                HKCS | 香港電腦學會
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#">首頁</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">關於我們</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">會員服務</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">活動</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">專業認證</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">聯絡我們</a></li>
                    <li class="nav-item ms-2">
                        <a class="btn btn-outline-primary btn-sm mt-1" href="#">會員登入</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- 橫幅輪播 -->
    <div id="mainCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="bg-primary text-white text-center py-5" style="height: 400px; display: flex; align-items: center; justify-content: center; flex-direction: column;">
                    <h1 class="display-4">HKCS 企業會員計劃</h1>
                    <p class="lead">加入香港電腦學會，提升專業水平</p>
                    <button class="btn btn-light btn-lg mt-3">了解更多</button>
                </div>
            </div>
            <div class="carousel-item">
                <div class="bg-info text-white text-center py-5" style="height: 400px; display: flex; align-items: center; justify-content: center; flex-direction: column;">
                    <h1 class="display-4">專業認證課程</h1>
                    <p class="lead">提升您的 IT 專業技能</p>
                    <button class="btn btn-light btn-lg mt-3">立即報名</button>
                </div>
            </div>
            <div class="carousel-item">
                <div class="bg-success text-white text-center py-5" style="height: 400px; display: flex; align-items: center; justify-content: center; flex-direction: column;">
                    <h1 class="display-4">學生會員優惠</h1>
                    <p class="lead">專為 IT 學生而設的優惠計劃</p>
                    <button class="btn btn-light btn-lg mt-3">查看詳情</button>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>

    <!-- 簡介區域 -->
    <section class="intro-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h2 class="display-5 mb-4">關於香港電腦學會</h2>
                    <p class="lead">成立於 1970 年，香港電腦學會是首個致力於發展香港資訊科技專業及行業的非牟利組織。</p>
                    <p>我們的會員來自香港 IT 界的各個範疇，包括企業和專業人士，共同努力提升專業水平和行業標準。</p>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="bi bi-award-fill" style="font-size: 8rem; opacity: 0.3;"></i>
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="#" class="btn btn-light btn-lg">關於我們</a>
            </div>
        </div>
    </section>

    <!-- 即將舉行活動 -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">即將舉行活動</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card event-card h-100">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="bi bi-calendar-event me-2 text-primary"></i>
                                HKICTA 2026: Smart Business Award
                            </h5>
                            <p class="card-text">歡迎來自金融服務、物流等業務範疇的參賽作品。</p>
                            <a href="#" class="btn btn-outline-primary">詳情</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card event-card h-100">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="bi bi-trophy me-2 text-warning"></i>
                                APICTA 2024
                            </h5>
                            <p class="card-text">香港代表團總共贏得 18 個獎項。</p>
                            <a href="#" class="btn btn-outline-primary">詳情</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card event-card h-100">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="bi bi-people-fill me-2 text-success"></i>
                                專業研討會 2026
                            </h5>
                            <p class="card-text">探討最新 IT 趨勢和專業發展機會。</p>
                            <a href="#" class="btn btn-outline-primary">詳情</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 功能單位 -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">功能單位</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card functional-card text-center p-4">
                        <div class="card-icon mb-3">
                            <i class="bi bi-laptop"></i>
                        </div>
                        <h5 class="card-title">CIO Board</h5>
                        <p class="card-text">為香港主要機構的資訊總監提供交流平台和分享見解。</p>
                        <a href="#" class="btn btn-link">詳情 <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card functional-card text-center p-4">
                        <div class="card-icon mb-3">
                            <i class="bi bi-shield-lock"></i>
                        </div>
                        <h5 class="card-title">CISO Board</h5>
                        <p class="card-text">為網絡安全主管提供交流平台，分享情報和見解。</p>
                        <a href="#" class="btn btn-link">詳情 <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card functional-card text-center p-4">
                        <div class="card-icon mb-3">
                            <i class="bi bi-diagram-3"></i>
                        </div>
                        <h5 class="card-title">Specialist Groups</h5>
                        <p class="card-text">專業小組是塑造香港 IT 未來的重要支柱。</p>
                        <a href="#" class="btn btn-link">詳情 <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card functional-card text-center p-4">
                        <div class="card-icon mb-3">
                            <i class="bi bi-building"></i>
                        </div>
                        <h5 class="card-title">Industry Groups</h5>
                        <p class="card-text">作為行業專業人士和業務高管之間的交流平台。</p>
                        <a href="#" class="btn btn-link">詳情 <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card functional-card text-center p-4">
                        <div class="card-icon mb-3">
                            <i class="bi bi-lightbulb"></i>
                        </div>
                        <h5 class="card-title">iLEAP</h5>
                        <p class="card-text">IT 領導力加速平台，為 IT 經理提供專業發展。</p>
                        <a href="#" class="btn btn-link">詳情 <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card functional-card text-center p-4">
                        <div class="card-icon mb-3">
                            <i class="bi bi-heart"></i>
                        </div>
                        <h5 class="card-title">FACE Club</h5>
                        <p class="card-text">香港首個 IT 女性俱樂部，連接和吸引女性 IT 專業人士。</p>
                        <a href="#" class="btn btn-link">詳情 <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 加入我們 CTA -->
    <section class="cta-section text-center">
        <div class="container">
            <h2 class="display-5 mb-4">立即加入我們</h2>
            <p class="lead mb-4">我們激勵志同道合的人士分享和推動 IT 專業發展</p>
            <a href="#" class="btn btn-cta btn-lg">
                <i class="bi bi-person-plus-fill me-2"></i>
                成為會員
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5>Hong Kong Computer Society</h5>
                    <p>香港電腦學會</p>
                    <p><i class="bi bi-geo-alt me-2"></i>香港數碼港</p>
                    <p><i class="bi bi-envelope me-2"></i>info@hkcs.org.hk</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>快速連結</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white text-decoration-none">關於我們</a></li>
                        <li><a href="#" class="text-white text-decoration-none">會員服務</a></li>
                        <li><a href="#" class="text-white text-decoration-none">活動</a></li>
                        <li><a href="#" class="text-white text-decoration-none">聯絡我們</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>關注我們</h5>
                    <div>
                        <a href="#" class="text-white me-3"><i class="bi bi-facebook fs-4"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-linkedin fs-4"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-youtube fs-4"></i></a>
                        <a href="#" class="text-white"><i class="bi bi-instagram fs-4"></i></a>
                    </div>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; 2026 Hong Kong Computer Society. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5.3.3 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>