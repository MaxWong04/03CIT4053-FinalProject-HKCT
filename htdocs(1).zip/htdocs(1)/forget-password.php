<?php
/* =========================================================================
   Group Number: [Insert Your Group Number, e.g., Group 7]
   Group Members: S24810493 WONG Lai Man (Max), [Teammate 2 ID & Name], [Teammate 3 ID & Name]
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Page 4 of 8 - Forget Password / Account Recovery Page (forget-password.php)
   ========================================================================= */

$pageTitle = "Forget Password | Hong Kong Computer Society (HKCS)";
$recoveryMessage = "";

// Handle PHP POST password recovery request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recoveryEmail = trim($_POST['recovery_email'] ?? '');
    if (!empty($recoveryEmail)) {
        $safeEmail = htmlspecialchars($recoveryEmail, ENT_QUOTES, 'UTF-8');
        $recoveryMessage = "Password reset instructions have been dispatched to <strong>{$safeEmail}</strong>. Please check your inbox.";
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Start of Page Banner: Sub-page title header for Password Recovery -->
<section class="page-banner text-center">
    <div class="container">
        <h1 class="fw-bold mb-2">Password Recovery</h1>
        <p class="mb-0 text-white-50">Reset your HKCS Member Portal credentials securely</p>
    </div>
</section>
<!-- End of Page Banner -->

<!-- Start of Forget Password Form Section: Single centered recovery card -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="auth-card p-4 p-lg-5 bg-white">
                    <h4 class="fw-bold mb-2" style="color: var(--hkcs-primary);">Forgot Your Password?</h4>
                    <p class="text-muted small mb-4">Enter the email address associated with your HKCS membership account. We will send a password reset verification link to your inbox.</p>

                    <?php if (!empty($recoveryMessage)): ?>
                        <div class="alert alert-success small" role="alert">
                            <?php echo $recoveryMessage; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="forget-password.php">
                        <!-- Registered Email Input -->
                        <div class="mb-3">
                            <label for="recoveryEmail" class="form-label fw-bold small">Registered Email Address</label>
                            <input type="email" class="form-control" id="recoveryEmail" name="recovery_email" placeholder="e.g., member@hkcs.org.hk" required>
                        </div>

                        <!-- Optional Membership ID Input for verification -->
                        <div class="mb-4">
                            <label for="recoveryMemberId" class="form-label fw-bold small">Membership ID (Optional)</label>
                            <input type="text" class="form-control" id="recoveryMemberId" name="recovery_member_id" placeholder="e.g., S24810493">
                        </div>

                        <!-- Submit Recovery Request Button -->
                        <button type="submit" class="btn btn-hkcs-primary w-100 py-2 mb-3">Send Reset Link</button>

                        <!-- Return Links to Login and Register Pages -->
                        <div class="d-flex justify-content-between small pt-3 border-top">
                            <a href="login.php" class="fw-bold text-decoration-none" style="color: var(--hkcs-primary);">&larr; Back to Member Login</a>
                            <a href="register.php" class="text-muted text-decoration-none">Create New Account</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of Forget Password Form Section -->

<?php
require_once __DIR__ . '/includes/footer.php';
?>