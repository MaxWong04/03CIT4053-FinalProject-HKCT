<?php 
require_once __DIR__ . '/includes/header.php'; 
?>

<!-- ========================================
     輪播橫幅區 (全螢幕寬度版本) | Hero Carousel (Full-width Version)
     ======================================== -->
<section class="hero-carousel-fullwidth">
    <div class="carousel-main-container">
        <?php if (!empty($carouselBanners)): ?>
            <?php foreach ($carouselBanners as $index => $banner): ?>
                <div class="carousel-slide <?php echo $index === 0 ? 'active' : ''; ?>">
                    <img src="<?php echo htmlspecialchars($banner['image'], ENT_QUOTES, 'UTF-8'); ?>" 
                         alt="<?php echo htmlspecialchars($banner['alt'], ENT_QUOTES, 'UTF-8'); ?>"
                         class="carousel-image"
                         onerror="if(this.src!=='<?php echo $banner['fallback']; ?>'){this.src='<?php echo $banner['fallback']; ?>';}">
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <!-- 左右箭頭 | Left/Right Arrows -->
        <button class="carousel-arrow prev" aria-label="Previous slide">‹</button>
        <button class="carousel-arrow next" aria-label="Next slide">›</button>
        
        <!-- 圓點指示器 | Dot Indicators -->
        <div class="carousel-dots">
            <?php if (!empty($carouselBanners)): ?>
                <?php foreach ($carouselBanners as $index => $banner): ?>
                    <button class="carousel-dot <?php echo $index === 0 ? 'active' : ''; ?>" 
                            data-slide="<?php echo $index; ?>"
                            aria-label="Go to slide <?php echo $index + 1; ?>"></button>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- 縮略圖導航條 | Thumbnail Navigation Strip -->
    <div class="carousel-thumbnail-strip">
        <div class="thumbnail-container">
            <?php if (!empty($carouselBanners)): ?>
                <?php foreach ($carouselBanners as $index => $banner): ?>
                    <div class="thumbnail-item <?php echo $index === 0 ? 'active' : ''; ?>" 
                         data-slide="<?php echo $index; ?>">
                        <img src="<?php echo htmlspecialchars($banner['image'], ENT_QUOTES, 'UTF-8'); ?>" 
                             alt="Thumbnail <?php echo $index + 1; ?>"
                             onerror="if(this.src!=='<?php echo $banner['fallback']; ?>'){this.src='<?php echo $banner['fallback']; ?>';}">
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- 即將舉行活動區塊 | Upcoming Events Section -->
<section class="events-section">
    <div class="container">
        <div class="section-title-wrap">
            <h2>Upcoming Events</h2>
            <p>Find out more about our upcoming events and supporting initiatives</p>
        </div>
        <?php if (!empty($upcomingEvents)): ?>
            <div class="events-grid">
                <?php foreach ($upcomingEvents as $event): ?>
                    <article class="event-card">
                        <span class="event-badge"><?php echo htmlspecialchars($event['badge'] ?? 'Event', ENT_QUOTES, 'UTF-8'); ?></span>
                        <h3><?php echo htmlspecialchars($event['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
                        <p><?php echo htmlspecialchars($event['desc'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <a href="<?php echo htmlspecialchars($event['link'], ENT_QUOTES, 'UTF-8'); ?>" class="btn-event-more">Read More <i class="fas fa-arrow-right"></i></a>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- 關於我們簡介區塊 | About HKCS Banner -->
<section class="intro-section">
    <div class="container">
        <div class="intro-content">
            <h2>About Hong Kong Computer Society</h2>
            <p class="lead-text">Established in 1970, HKCS is the first non-profit professional body devoted to building Hong Kong’s ICT industry.</p>
            <p>Our members come from a wide range of ICT disciplines across executive, professional and academic sectors.</p>
            <a href="overview.php" class="btn btn-intro">Learn More About Us</a>
        </div>
    </div>
</section>

<!-- 功能單位區塊 | Functional Units Section -->
<section class="units-section">
    <div class="container">
        <div class="section-title-wrap">
            <h2>Functional Units</h2>
            <p>Empowerment through key governance boards and specialist groups</p>
        </div>
        
        <?php if (!empty($functionalUnits)): ?>
            <div class="unit-grid">
                <?php foreach ($functionalUnits as $unit): ?>
                    <article class="unit-card">
                        <h3><?php echo htmlspecialchars($unit['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
                        <p><?php echo htmlspecialchars($unit['desc'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <a href="<?php echo htmlspecialchars($unit['link'], ENT_QUOTES, 'UTF-8'); ?>" 
                           class="btn btn-more">More Details <i class="fas fa-arrow-right"></i></a>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php 
require_once __DIR__ . '/includes/footer.php'; 
?>