<?php
/* =========================================================================
   Group Number: [Group 7]
   Group Members: S24810493 WONG Lai Man (Max), [YULIN LIAO], [JIEYI WANG]
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Shared PHP Footer providing direct navigation links to all 8 interconnected PHP pages
   ========================================================================= */
?>
    </main>
    <!-- End of Main Content Wrapper -->

    <!-- Start of Site Footer: Ensures all 8 required PHP pages are directly accessible from every page -->
    <footer class="main-footer pt-5 pb-3">
        <div class="container">
            <div class="row g-4 pb-4">
                <!-- Footer Column 1: HKCS Secretariat Contact Information -->
                <div class="col-lg-5 col-md-6">
                    <h5 class="text-white fw-bold mb-3">Hong Kong Computer Society</h5>
                    <p class="small mb-2"><?php echo htmlspecialchars($contactInfo['address'], ENT_QUOTES, 'UTF-8'); ?></p>
                    <p class="small mb-1">Email: <?php echo htmlspecialchars($contactInfo['email'], ENT_QUOTES, 'UTF-8'); ?></p>
                    <p class="small mb-0">Tel: <?php echo htmlspecialchars($contactInfo['phone'], ENT_QUOTES, 'UTF-8'); ?></p>
                </div>

                <!-- Footer Column 2: Core Content PHP Pages (Pages 1, 5, 6, 7) -->
                <div class="col-lg-3 col-md-6">
                    <h5 class="text-white fw-bold mb-3">Quick Navigation</h5>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><a href="index.php" class="text-white-50 text-decoration-none">Home Page</a></li>
                        <li class="mb-2"><a href="events.php" class="text-white-50 text-decoration-none">Events &amp; Programmes (Item List)</a></li>
                        <li class="mb-2"><a href="event-detail.php" class="text-white-50 text-decoration-none">Featured Event (Item Detail)</a></li>
                        <li class="mb-2"><a href="faq.php" class="text-white-50 text-decoration-none">Frequently Asked Questions (FAQ)</a></li>
                    </ul>
                </div>

                <!-- Footer Column 3: Account & Support PHP Pages (Pages 2, 3, 4, 8) -->
                <div class="col-lg-4 col-md-12">
                    <h5 class="text-white fw-bold mb-3">Member Portal &amp; Support</h5>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><a href="login.php" class="text-white-50 text-decoration-none">Member Login</a></li>
                        <li class="mb-2"><a href="register.php" class="text-white-50 text-decoration-none">Membership Registration</a></li>
                        <li class="mb-2"><a href="forget-password.php" class="text-white-50 text-decoration-none">Forget Password / Recovery</a></li>
                        <li class="mb-2"><a href="contact.php" class="text-white-50 text-decoration-none">Contact Us</a></li>
                    </ul>
                </div>
            </div>

            <!-- Dynamic PHP Copyright Year -->
            <div class="border-top border-secondary pt-3 text-center small text-white-50">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Hong Kong Computer Society. All rights reserved.</p>
            </div>
        </div>
    </footer>
    <!-- End of Site Footer -->

    <!-- Official Bootstrap 5.3.3 JS Bundle CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom project JavaScript file -->
    <script src="assets/js/main.js"></script>
</body>
</html>