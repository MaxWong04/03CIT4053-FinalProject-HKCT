<?php
/* =========================================================================
   Group Number: [Insert Your Group Number, e.g., Group 7]
   Group Members: S24810493 WONG Lai Man (Max), [Teammate 2 ID & Name], [Teammate 3 ID & Name]
   Date: 2026-11-16
   Assignment Title: Final Project Part I - Hong Kong Computer Society (HKCS) Website Rebuild
   File Description: Page 2 of 8 - Member Login Page (login.php) with PHP POST validation feedback
   ========================================================================= */

$pageTitle = "Member Login | Hong Kong Computer Society (HKCS)";
$loginMessage = "";
$loginStatus = "";

// Handle PHP POST form submission for member login demonstration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['login_identifier'] ?? '');
    $password   = trim($_POST['login_password'] ?? '');

    if (!empty($identifier) && !empty($password)) {
        $safeUser = htmlspecialchars($identifier, ENT_QUOTES, 'UTF-8');
        $loginStatus = "success";
        $loginMessage = "Welcome back, <strong>{$safeUser}</strong>! Authentication verified via HKCS Member Portal.";
    } else {
        $loginStatus = "danger";
        $loginMessage = "Please enter both your Membership ID / Email and Password.";
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Start of Page Banner: Sub-page title header for Member Login -->
<section class="page-banner text-center">
    <div class="container">
        <h1 class="fw-bold mb-2">HKCS Member Portal Login</h1>
        <p class="mb-0 text-white-50">Access your digital membership card, CPD records, and exclusive ICT events</p>
    </div>
</section>
<!-- End of Page Banner -->

<!-- Start of Login Form Section: Centered two-column authentication card -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-9 col-md-11">
                <div class="auth-card overflow-hidden">
                    <div class="row g-0">
                        <!-- Left Info Column: Highlights HKCS digital membership benefits -->
                        <div class="col-md-5 text-white p-4 d-flex flex-column justify-content-between" style="background: linear-gradient(160deg, var(--hkcs-primary) 0%, #003a7d 100%);">
                            <div>
                                <h4 class="fw-bold mb-3">Welcome Back</h4>
                                <p class="small text-white-50 mb-4">Sign in with your HKCS Membership ID or registered email address to manage your profile and event registrations.</p>
                                <ul class="small ps-3 mb-0">
                                    <li class="mb-2">iAM Smart Digital Membership Card</li>
                                    <li class="mb-2">Continuing Professional Development (CPD) Tracking</li>
                                    <li class="mb-2">Specialist &amp; Industry Group Communities</li>
                                </ul>
                            </div>
                            <div class="pt-4 border-top border-light border-opacity-25 small">
                                <span class="text-white-50">Need assistance?</span>
                                <a href="contact.php" class="text-white fw-bold text-decoration-underline ms-1">Contact Secretariat</a>
                            </div>
                        </div>

                        <!-- Right Form Column: Interactive PHP POST login form -->
                        <div class="col-md-7 p-4 p-lg-5 bg-white">
                            <h4 class="fw-bold mb-4" style="color: var(--hkcs-primary);">Sign In to Your Account</h4>

                            <?php if (!empty($loginMessage)): ?>
                                <div class="alert alert-<?php echo $loginStatus; ?> small" role="alert">
                                    <?php echo $loginMessage; ?>
                                </div>
                            <?php endif; ?>

                            <form method="POST" action="login.php">
                                <!-- Membership ID or Email Input -->
                                <div class="mb-3">
                                    <label for="loginIdentifier" class="form-label fw-bold small">Membership ID or Registered Email</label>
                                    <input type="text" class="form-control" id="loginIdentifier" name="login_identifier" placeholder="e.g., S24810493 or member@hkcs.org.hk" required>
                                </div>

                                <!-- Password Input -->
                                <div class="mb-3">
                                    <label for="loginPassword" class="form-label fw-bold small">Password</label>
                                    <input type="password" class="form-control" id="loginPassword" name="login_password" placeholder="Enter your password" required>
                                </div>

                                <!-- Remember Me Checkbox & Forget Password Link -->
                                <div class="d-flex justify-content-between align-items-center mb-4 small">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="rememberMe" name="remember_me">
                                        <label class="form-check-label text-muted" for="rememberMe">Remember me</label>
                                    </div>
                                    <a href="forget-password.php" class="fw-bold text-decoration-none" style="color: var(--hkcs-primary);">Forgot Password?</a>
                                </div>

                                <!-- Submit Login Button -->
                                <button type="submit" class="btn btn-hkcs-primary w-100 py-2 mb-3">Sign In</button>

                                <!-- Link to Registration Page -->
                                <p class="text-center small text-muted mb-0">
                                    Not an HKCS member yet? 
                                    <a href="register.php" class="fw-bold text-decoration-none" style="color: var(--hkcs-primary);">Register Now</a>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of Login Form Section -->

<?php
require_once __DIR__ . '/includes/footer.php';
?>